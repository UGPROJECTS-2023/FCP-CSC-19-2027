<?php
require 'admin/incs/connect.php';
session_start();
$err = array();
function validate($data){
	require 'admin/incs/connect.php';
	$data = filter_var($data, FILTER_SANITIZE_STRING);
	$data = htmlspecialchars($data);
	$data = stripcslashes($data);
	$data = mysqli_real_escape_string($conn, $data);

	return $data;
}

if(isset($_POST['submit'])){
	$username = validate($_POST['regno']);
	$password = validate($_POST['password']);
	$cpassword = validate($_POST['cpassword']);

	if(empty($username) || empty($password) || empty($cpassword)){
		array_push($err, "All fields are required");
	}
	$query = $conn->query("SELECT `regno` FROM `users` WHERE `regno` = '$username'");
	$row = $query->fetch_assoc();
	if($row){
		if($row['regno'] === $username){
			array_push($err, $username . " already exist");
		}
	}
	// if((!preg_match("/^[a-zA-Z ]*$/", $username)) || (strpos($username, ' '))){
	// 	array_push($err, "username must not contain special characters or space");
	// }

	if($password != $cpassword){
		array_push($err, "The  two passwords did not match");
	}

	$modified = md5($password);

	if(count($err) == 0){
		$sql = "INSERT INTO `users` (`regno`, `password`) VALUES ('$username', '$modified')";
		if($conn->query($sql) === TRUE){
			$_SESSION['advanced_fudite_session'] = $username;
			header("location: index.php");
		}
		else{
			array_push($err, "FAILED TO CREATE YOUR ACCOUNT, TRY AGAIN LATER");
		}
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>FudMyVote | Register</title>
	<?php require "incs/header.php" ?>
	<style type="text/css">
		body{
			background: linear-gradient(rgba(0,0,0,0.7), #000), url("img/ngate.jpg");
			background-attachment: fixed;
			background-size: cover;
			background-position: center;
		}
		.box{
			padding: 50px;
			background: rgba(0, 0, 0, 0.5);
			margin-top: 5%;
		}
		.box_header, .box_footer{
			padding: 0px;
			text-align: center;
			color: #fff;
		}
		label{color: #b1b1b1; font-family: lucida console; font-weight: bolder; font-size: 12px;}
		.box_body input, .box_body input:hover, .box_body input:focus {border-radius: 0; font-weight: bolder; background: inherit; color: #b1b1b1; border: 5px solid tomato; border-top: 0; border-bottom: 0;}
		.box_body button{border-radius: 0; font-weight: bolder; background: inherit; color: #fff; border: 0;}
		.logo_img{width: 15%;}


	</style>
</head>
<body>
<div class="box container">
	<div class="box_main">
		<div class="box_header">
			<img src="img/fud.png" class="logo_img">

			<?php
				foreach ($err as $key => $value) {
					echo "<div class = 'alert alert-danger mt-4'><b>$value</b></div>";
				}
			?>
			
		</div>
		<div class="box_body">
			<form action="register.php" method="POST">
				<div class="form-group">
					<label for="userame"><span class="fa fa-user"></span> Registration Number</label>
					<input type="text" name="regno" class="form-control" placeholder="FAC/DEPT/YEAR/NUMB" required>
				</div>
				<div class="form-group">
					<label for="password"><span class="fa fa-lock"></span> Password</label>
					<input type="password" name="password" class="form-control" placeholder="**********" required>
				</div>

				<div class="form-group">
					<label for="cpassword"><span class="fa fa-lock"></span> Confirm Password</label>
					<input type="password" name="cpassword" class="form-control" placeholder="**********" required>
				</div>

				<div class="form-group">
					<button type="submit" class="btn btn-success btn-block btn-lg" name="submit">Sign up</button>
				</div>
			</form>


		</div>

		<div class="box_footer">
			Already have an accout, <a href="login.php">Click here to login</a>
		</div>
	</div>
</div>
</body>
</html>