
window.onscroll = function(){
    show_btn();
  }
  function show_btn(){
    if(document.body.scrollTop > 20 || document.documentElement.scrollTop > 20){
      document.getElementById('to_top').style.display = "block";
    }
    else{
      document.getElementById('to_top').style.display = "none";
    }
  }

  function move_me_upward(){
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
  }
  let text = "SpaceNotes.com";
  let speed = 150;
  var i = 0;
  function welcome(){
    if(i < text.length){
      document.getElementById('page_welcome_text').innerHTML += text.charAt(i);
      i++;
      setTimeout(welcome, speed);
    }
  }
  welcome();

  function validate(form){
    if(document.getElementById("search").value == ""){
      alert("Your input field is empty!! Please, Enter a valid input");
      return false;
    }
    return true;
  }
