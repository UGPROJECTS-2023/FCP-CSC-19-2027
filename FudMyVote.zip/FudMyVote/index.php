<?php 
require 'admin/incs/connect.php';

session_start();
$err = array();
if(!isset($_SESSION['advanced_fudite_session'])){
	header("location: login.php");
}
else{
	$user = $_SESSION['advanced_fudite_session'];
	$play = $conn->query("SELECT * FROM `users` WHERE `regno` = '$user'");
	$me = $play->fetch_assoc();

	$my_id = $me['id'];
}

$query = $conn->query("SELECT * FROM `vote`");
$labels = $query->fetch_assoc();
$date = date("Y-m-d");

$det = false;
if($date == $labels['date'] && $labels['status'] == 1){
	$det = true;
}
else{
	$det = false;
}

if(!$det){
	die("<h1><center><i>Election is not available</center></i></h1>");
}



if(isset($_GET['logout'])){
	session_destroy();
	unset($_SESSION['advanced_fudite_session']);
	header("location: login.php");
}

if(isset($_POST['cast_vote'])){
	$candidate_id = $_POST['candidate_id'];
	$position_id = $_POST['position_id'];

	$query = "INSERT INTO `voters` (`voter_id`, `candidate_id`, `position_id`) VALUES ('$my_id', '$candidate_id', '$position_id')";
	if($conn->query($query)){
		echo "<script>alert('Vote Cast Successfully!')</script>";
	}
	else{
		echo "<script>alert('System Failed to cast vote, try again later')</script>";	
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo strtolower($_SESSION['advanced_fudite_session']) ?>'s Vote panel</title>
	<?php require 'incs/header.php'; ?>
	<style type="text/css">
		body{
			background: #111;
		}
		.right_nav{position: absolute; right: 50px;}
		.header{
			background: #292F33;
			color: #fff;
			padding: 20px;
			text-align: center;
		}
		.navbar{
			background: #000 !important;
			border-radius: 0 !important;
		}
		.text_white{color: #fff;}
		.banner{background: rgba(0, 0, 0, 0.5); padding: 20px;}
		.card{border: 0; border-radius: 0; margin-bottom: 30px;}
		.candi_image{
			width: 100%;
			height: 300px;
		}
		.card-header, .card-footer{
			background: linear-gradient(to left, #292F33, #000);
			color: #fff;
			/*font-weight: bolder;*/
			text-align: center;
			font-family: lucida console;
		}
		.card-body{background: #000;}
		.total{
			padding: 10px;
			color: beige;
			font-family: georgia;
			font-weight: bolder;
			font-size: 19px;
		}
		.
	</style>
</head>
<body>
<?php include "incs/navvbar.php" ?>
<div class="container mt-4">
	<h4 class="text-primary text-center mb-4">Welcome To <?php echo $labels['name']; ?></h4>
	<?php
		$sql = "SELECT * FROM `cat`";
		$result = $conn->query($sql);
		while($row = $result->fetch_assoc()):
	?>
	<div class="card">
		<div class="card-header">
			<h4>
				Contesting For "<?php 
				$name = $row['name'];
				$position_id = $row['id'];
				echo $name;
			 ?>"
			</h4>
		</div>
		<div class="card-body">
			<div class="row">
				<?php  
					$page = 0;

					$query = "SELECT * FROM `candidates` WHERE `position` = '$name'";
					$call = $conn->query($query);
					$candis = $call->num_rows;
					if($candis > 0){
						$page = 12 / $candis;
					}

					// my_id

					while($col = $call->fetch_assoc()):
						$candidate_id = $col['id'];
				?>
				<div class="col-md-<?php echo $page ?>">
					<div class="card">
						<div class="card-header">
							<h5><?php echo $col['name']; ?></h5>
						</div>
						<div class="card-body">
							<img src="img/candidates/<?php echo $col['photo']; ?>" class = "candi_image">
							<div class="text-center counter">
								<?php  
									$data = "SELECT * FROM `voters`WHERE `candidate_id` = '$candidate_id'";
									$hat = $conn->query($data);
									$total_votes = $hat->num_rows;
								?>
								<div class="total">
									Total Votes (<?php echo $total_votes; ?>)
								</div>
							</div>
						</div>
						<div class="card-footer">
							<!-- <form action="index.php" method="POST"> -->
								<!-- <input type="hidden" name="candidate" value="<?php echo $row['id'] ?>"> -->
								<?php  
									$data = "SELECT * FROM `voters` WHERE `voter_id` = '$my_id' AND `position_id` = '$position_id'";
									$hat = $conn->query($data);
									$total_votes = $hat->num_rows;
									if($total_votes > 0){
								?>
								<button class="btn btn-success btn-block disabled" style="cursor: not-allowed; background: inherit;">Voted Already</button>
								<?php 
								}
								else{
								?>
								<button class="btn btn-primary btn-block" style="background: inherit; border: 1px solid grey;" data-toggle = "modal" data-target = "#modal_view_candidate_<?php echo $col['id'] ?>">Vote</button>
								<?php } ?>
							<!-- </form> -->

						</div>
					</div>
				</div>
				<?php endwhile; ?>
			</div>
		</div>
		<!-- <div class="card-footer">
			<img src="img/fud.png" style="width: 5%"> Vote Wisely | Your Vote Matters | Fudites Decide | A Good leader is a healthy society | FUD Students are Academic Soldiers | <img src="img/fud.png" style="width: 5%">
		</div> -->
	</div>
<?php endwhile; ?>
</div>

<?php
$query = $conn->query("SELECT * FROM `candidates`");
while($row = $query->fetch_assoc()):
	$pos = $row['position'];
	$sql = "SELECT * FROM `cat` WHERE `name` = '$pos'";
	$run = $conn->query($sql);
	$data = $run->fetch_assoc();
?>
<div class="modal fade" id="modal_view_candidate_<?php echo $row['id'] ?>">
	<div class="modal-dialog modal-md">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">
					Vote For <?php echo $row['name'] . " for " . $row['position'] . " ?"; ?>
				</h5>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>
			<div class="modal-body" style="font-weight: bold; font-family: georgia;">
				<div class="form-group">
					<center>
						<img src="img/candidates/<?php echo $row['photo'] ?>" style = "width: 200px; height: 200px; border-radius: 50%;">
					</center>
				</div>
				<div class="form-group">
					Full Name: <?php echo $row['name']; ?>
				</div>
				<div class="form-group">
					Department: <?php echo $row['dept']; ?>
				</div>
				<div class="form-group">
					Faculty: <?php echo $row['faculty']; ?>
				</div>
				<div class="form-group">
					Level: <?php echo $row['level']; ?>
				</div>
				<div class="form-group">
					Contesting for: <?php echo $row['position']; ?>

				</div>
				<form action="index.php" method="POST">
					<input type="hidden" name="candidate_id" value="<?php echo $row['id'] ?>">
					<input type="hidden" name="position_id" value="<?php echo $data['id'] ?>">
					<button type="submit" name="cast_vote" class="btn btn-primary btn-block btn-lg">Cast Vote</button>
					<button type="button" class="btn btn-info btn-lg btn-block" data-dismiss = "modal">No</button>
				</form>

			</div>
		</div>
	</div>
</div>
<?php endwhile; ?>
</body>
</html>