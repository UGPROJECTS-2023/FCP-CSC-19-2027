<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Vote Results</title>
	<link rel="icon" type="image/icon type" href="../img/fud.png">
<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="../css/style.css">
<link rel="stylesheet" type="text/css" href="../css/fontawesome-all.css">
	<style type="text/css">
		body{
			background: #efefef;
		}
		
		.card{
			background: linear-gradient(#efefef, #fff);
		}
		.card{ margin-bottom: 30px;text-align: center;}
		.candi_image{
			width: 300px;
			height: 300px;
			border-radius: 50%;

		}
		.card-header, .card-footer{
			
			/*font-weight: bolder;*/
			text-align: center;
			font-family: lucida console;
		}
		
		.total{
			padding: 10px;
			color: teal;
			font-family: georgia;
			font-weight: bolder;
			font-size: 19px;
		}
		.main{
			box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
		}
	</style>
</head>
<body>
<div class="container mt-4">
	<h4 class="text-info text-center mb-4">
		<?php
		require 'incs/connect.php';
			$query = $conn->query("SELECT * FROM `vote`");
			$row = $query->fetch_assoc();
			echo $row['name'];
		?> Results
	</h4>
	<?php
	
		$sql = "SELECT * FROM `cat`";
		$result = $conn->query($sql);
		while($row = $result->fetch_assoc()):
	?>
	<div class="card main">
		<div class="card-header">
			<h4>
				 For "<?php 
				$name = $row['name'];
				$position_id = $row['id'];
				echo $name;
			 ?>"
			</h4>
		</div>
		<div class="card-body">
			<div class="row">
				<?php  
					$page = 0;

					$query = "SELECT * FROM `candidates` WHERE `position` = '$name'";
					$call = $conn->query($query);
					$candis = $call->num_rows;
					if($candis > 0){
						$page = 12 / $candis;
					}

					// my_id

					while($col = $call->fetch_assoc()):
						$candidate_id = $col['id'];
				?>
				<div class="col-md-<?php echo $page ?>">
					<div class="card">
						<div class="card-header">
							<h5><?php echo $col['name']; ?></h5>
						</div>
						<div class="card-body">
							<img src="../img/candidates/<?php echo $col['photo']; ?>" class = "candi_image">
							<div class="text-center counter">
								<?php  
									$data = "SELECT * FROM `voters`WHERE `candidate_id` = '$candidate_id'";
									$hat = $conn->query($data);
									$total_votes = $hat->num_rows;
								?>
								<!-- <div class="total">
									Total Votes (<?php echo $total_votes; ?>)
								</div> -->
							</div>
						</div>
						<div class="card-footer">
							<div class="total">
									Total Votes (<?php echo $total_votes; ?>)
								</div>

						</div>
					</div>
				</div>
				<?php endwhile; ?>
			</div>
		</div>
		<!-- <div class="card-footer">
			<img src="img/fud.png" style="width: 5%"> Vote Wisely | Your Vote Matters | Fudites Decide | A Good leader is a healthy society | FUD Students are Academic Soldiers | <img src="img/fud.png" style="width: 5%">
		</div> -->
	</div>
<?php endwhile; ?>
</div>

<script type="text/javascript">
	window.print();
</script>
</body>
</html>