<?php
//This is the connection part of the database
$dbhostname = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "vote";

$conn = @new mysqli($dbhostname, $dbusername, $dbpassword, $dbname);
//when an inevitable error occured throw an exception
try{
	if($conn->connect_error){
		throw new Exception("<b>Failed to connect with the database</b>");
	}
}
catch(Exception $ex){
	//display the error
	echo "Error: " . $ex->getMessage();
}
?>