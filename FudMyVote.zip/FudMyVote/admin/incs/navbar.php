<div class="header">
    <div class="inner_header">
        <h3><span class="fab fa-superpowers"></span> FudMyVote Admin </h3>
    </div>
</div>
<nav class="navbar navbar-expand-md bg-dark navbar-dark">
    <a class="navbar-brand" href="#"><span class="fab fa-superpowers"></span> FudMyVote App</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav">
             <li class="nav-item">
                <a class="nav-link text_white" href="index.php" style="color: #fff;"><span class="fa fa-home"></span> Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text_white" href="users.php" style="color: #fff;"><span class="fa fa-bolt"></span> Manage Users</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="category.php" style="color: #fff;"><span class="fa fa-list"></span> Vote Categories</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="candidates.php" style="color: #fff;"><span class="fa fa-users"></span> Candidates</a>
            </li>   
          
        </ul>

      <ul class="navbar-nav right_nav">
          <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown" style="color: #fff;">
                <?php echo "@" . strtolower($_SESSION['advanced_admin_session']); ?>
              </a>
              <div class="dropdown-menu">
                <a class="dropdown-item" href="index.php?logout=1">Logout</a>
              </div>
          </li>
      </ul>
    </div>  
</nav>