<!DOCTYPE html>
<?php 
session_start();
require 'incs/connect.php';
if(!isset($_SESSION['advanced_admin_session'])){
	header("location: login.php");
}
function validate($data){
		require 'incs/connect.php';
		$data = filter_var($data, FILTER_SANITIZE_STRING);
		$data = htmlspecialchars($data);
		$data = stripcslashes($data);
		$data = mysqli_real_escape_string($conn, $data);

		return $data;
	}
if(isset($_POST['submit'])){
	

	$cat = validate($_POST['cat']);

	if(empty($cat)){
		echo "<script>alert('All fields are required')</script>";
	}
	else{
		if($query = $conn->query("INSERT INTO `cat` (`name`) VALUES ('$cat')")){
			echo "<script>alert('Added Successfully!!!')</script>";
			header("location: category.php");
		}
	}

}

if(isset($_POST['edit'])){
	$name = validate($_POST['names']);
	$id = $_POST['id'];
	if(!empty($name)){
		if($query = $conn->query("UPDATE `cat` SET `name` = '$name' WHERE `id` = '$id'")){
			echo "<script>alert('Updated Successfully!')</script>";
			header("location: category.php");
		}
	}
}
if(isset($_POST['delete'])){
	$id = $_POST['dels'];
	if($conn->query("DELETE FROM `cat` WHERE `id` = '$id'")){
		echo "<script>alert('Deleted Successfully!')</script>";
		header("location: category.php");
	}
}
?>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Vote Category</title>
	<?php require "incs/header.php"; ?>
	<style type="text/css">
		body{
			background: #292F33;
		}
		.card-header{
			border-radius: 0;
			border: 0;
		}
		.card-body{color: #fff; text-align: left; background: rgba(0, 0, 0, 0.8); border: 1px solid #555;}label{font-size: 12px; text-align: left !important;}
		.card-body input, .card-body input:hover, .card-body input:focus {
			border-radius: 0;
			background: #000;
			border: 0;
			border-left: 5px solid red;
			border-right: 5px solid red;
			color: #fff;
		}
	</style>
</head>
<body>
<?php include 'incs/navbar.php'; ?>
<div class="container-fluid mt-4">
	<h3 class="text-primary">Vote Categories</h3>
	<div class="row">
		<div class="col-md-6">
			<div class="card">
				<div class="card-header">
					Voting Category
				</div>
				<div class="card-body">
					<form action="category.php" method="POST">
						<div class="form-group">
							<label for="cat">Category Name</label>
							<input type="text" name="cat" class="form-control" required>
						</div>
						<div class="form-group">
							<button type="submit" name="submit" class="btn btn-success btn-block"><span class="fa fa-plus"></span> Add</button>
						</div>
					</form>
				</div>
			</div>
		</div>

		<div class="col-md-6">
			<table class="table table-dark">
				<tr>
					<th>S/N</th>
					<th>Name</th>
					<th>Edit</th>
					<th>Delete</th>
				</tr>
				<?php
					$query = "SELECT * FROM `cat`";
					$result  = $conn->query($query);
					if($result->num_rows == 0){
						echo "<tr rowspan = '1'><th>NO RECORD FOUND!!</th></tr>";
					}
					$sn = 0;
					while($row = $result->fetch_assoc()):
						$sn += 1;
					?>
				<tr>
					<td><?php echo $sn; ?></td>
					<td><?php echo $row['name'] ?></td>
					<td><button class="btn btn-success" data-toggle="modal" data-target="#modal_edit_<?php echo $row['id'] ?>"><span class="fa fa-edit"></span> Edit</button></td>
					<td><button class="btn btn-warning" data-toggle="modal" data-target="#modal_delete_<?php echo $row['id'] ?>"><span class="fa fa-archive"></span> Delete</button></td>
				</tr>
				<?php endwhile; ?>
			</table>
		</div>
	</div>
</div>

<?php
$query = $conn->query("SELECT * FROM `cat`");
while($row = $query->fetch_assoc()):

?>
<div class="modal fade" id="modal_edit_<?php echo $row['id'] ?>">
	<div class="modal-dialog modal-sm">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">
					Edit <?php echo $row['name'] ?>
				</h5>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>
			<div class="modal-body">
				<form action="category.php" method="POST">
					<div class="form-group">
						<label>Category name</label>
						<input type="text" name="names" class="form-control" value="<?php echo $row['name'] ?>" required>
					</div>
					<input type="hidden" name="id" value="<?php echo $row['id'] ?>">
					<div class="form-group">
						<button type="submit" name="edit" class="btn btn-primary btn-block"><span class="fa fa-edit"></span> Update</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="modal_delete_<?php echo $row['id'] ?>">
	<div class="modal-dialog modal-sm">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">
					Delete <?php echo $row['name'] ?> ?
				</h5>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>
			<div class="modal-body">
				<form action="category.php" method="POST">
					<input type="hidden" name="dels" value="<?php echo $row['id'] ?>">
					<button type="submit" name="delete" class="btn btn-warning btn-lg btn-block">Yes</button>
					<button type="button" class="btn btn-success btn-lg btn-block" data-dismiss = "modal">No</button>
				</form>

			</div>
		</div>
	</div>
</div>
<?php endwhile; ?>
</body>
</html>