<?php
session_start();
$err = array();
require 'incs/connect.php';
if(!isset($_SESSION['advanced_admin_session'])){
	header("location: login.php");
}
if(isset($_GET['logout'])){
	session_destroy();
	unset($_SESSION['advanced_admin_session']);
	header("location: login.php");
}

if(isset($_POST['submit'])){
	$name = $_POST['cname'];
	$faculty = $_POST['cfac'];
	$level = $_POST['clevel'];
	$dept = $_POST['cdept'];
	$position = $_POST['cposition'];
	$photo = $_FILES['photo']['name'];
	$tmp = $_FILES['photo']['tmp_name'];

	$random = substr(bin2hex(random_bytes(15)), 0, 15);
	$file_extension = strtolower(pathinfo($photo, PATHINFO_EXTENSION));
	$target = "../img/candidates/" . basename($photo);

	if($file_extension != "jpg" && $file_extension != "jpeg" && $file_extension != "png"){
		array_push($err, "Invalid file type " . $file_extension);
	}

	if(empty($name) || empty($dept) || empty($photo)){
		array_push($err, "All fields are required");
	}

	if(count($err) == 0){
		$updates = $photo . "__candidate__" . $random . "." . $file_extension;

		if(move_uploaded_file($tmp, $target . "__candidate__" . $random . "." . $file_extension)){

			$query = "INSERT INTO `candidates` (`name`, `dept`, `faculty`, `level`, `position`, `photo`) VALUES ('$name', '$dept', '$faculty', '$level', '$position', '$updates')";
			if($result = $conn->query($query)){
				header("location: candidates.php");
			}
			else{
				array_push($err, "Failed to create candidate account");
			}
		}
	}
}

if(isset($_POST['edit'])){
	$name = $_POST['cname'];
	$faculty = $_POST['cfac'];
	$level = $_POST['clevel'];
	$dept = $_POST['cdept'];
	$position = $_POST['cposition'];

	$id = $_POST['id'];

	$query = "UPDATE  `candidates` SET `name` = '$name', `dept` = '$dept', `faculty` = '$faculty', `level` = '$level', `position` = '$position' WHERE `id` = '$id'";
	if($result = $conn->query($query)){
		header("location: candidates.php");
	}
	else{
		array_push($err, "Failed to create candidate account");
	}
}

if(isset($_POST['update_profile'])){

	$photo = $_FILES['image']['name'];
	$tmp = $_FILES['image']['tmp_name'];

	$id = $_POST['pict_id'];

	$file_extension = strtolower(pathinfo($photo, PATHINFO_EXTENSION));
	$target = "../img/candidates/" . basename($photo);

	if($file_extension != "jpg" && $file_extension != "jpeg" && $file_extension != "png"){
		echo "<script>alert('Invalid file type')</script>";
	}

	$sql = "SELECT  `photo` FROM `candidates` WHERE `id` = '$id'";
	$result = $conn->query($sql);
	$row = $result->fetch_assoc();

	unlink($target . "/" . $row['photo']);

	if(move_uploaded_file($tmp, $target)){
		$sql = "UPDATE `candidates` SET `photo` = '$photo' WHERE `id` = '$id'";
		if($conn->query($sql)){
			header("location: candidates.php");
		}
	}

}

if(isset($_POST['delete'])){
	$user_id = $_POST['dels'];
	$image = $_POST['hoto'];


	if($sql = $conn->query("DELETE FROM `candidates` WHERE `id` = '$user_id'") && unlink("../img/candidates/" . $image)){
		header("location: candidates.php");
	}


}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Candidates Page</title>
	<?php require "incs/header.php"; ?>
	<style type="text/css">
		body{background: #292F33;}

		.card-header{
			border-radius: 0;
			border: 0;
		}
		.card-body{color: #fff; text-align: left; background: rgba(0, 0, 0, 0.8); border: 1px solid #555;}label{font-size: 12px; text-align: left !important;}
		.card-body input, .card-body input:hover, .card-body input:focus {
			border-radius: 0;
			background: #000;
			border: 0;
			border-left: 5px solid red;
			border-right: 5px solid red;
			color: #fff;
		}
		label{margin-top: 0 !important;}
		.image_circle{
			width: 100%;
			height: 50px;
			border-radius: 10%;
			transition: 0.3s;
			cursor: pointer;
		}
		.image_circle:hover{opacity: .7;}
		.box{
			display: none; /* Hidden by default */
		    position: fixed; /* Stay in place */
		    z-index: 1; /* Sit on top */
		    padding-top: 100px; /* Location of the box */
		    left: 0;
		    top: 0;
		    width: 100%; /* Full width */
		    height: 100%; /* Full height */
		    overflow: auto; /* Enable scroll if needed */
		    background-color: rgb(0,0,0); /* Fallback color */
		    background-color: rgba(0,0,0,0.9);
		}

		.box_content{
			margin: auto;
		    display: block;
		    width: 80%;
		    max-width: 700px;
		}
		#capt{
			 margin: auto;
		    display: block;
		    width: 80%;
		    max-width: 700px;
		    text-align: center;
		    color: #ccc;
		    padding: 10px 0;
		    height: 150px;
		    font-size: 25px;
		    font-weight: bold;
		}

		.box_content, #capt{
			-webkit-animation-name: zoom;
		    -webkit-animation-duration: 0.6s;
		    animation-name: zoom;
		    animation-duration: 0.6s;
		}
		@-webkit-keyframes zoom {
		    from {-webkit-transform:scale(0)} 
		    to {-webkit-transform:scale(1)}
		}
		@keyframes zoom {
		    from {transform:scale(0)} 
		    to {transform:scale(1)}
		}
		.closer {
		    position: absolute;
		    top: 15px;
		    right: 35px;
		    color: #f1f1f1;
		    font-size: 40px;
		    font-weight: bold;
		    transition: 0.3s;
		}

		.closer:hover,
		.closer:focus {
		    color: #bbb;
		    text-decoration: none;
		    cursor: pointer;
		}

		select{
			border: 0 !important;
			border-left: 5px solid red !important;
			border-right: 5px solid red !important;
		}

		/* 100% Image Width on Smaller Screens */
		@media only screen and (max-width: 700px){
		    .box_content {
		        width: 100%;
		    }
		}

	</style>
</head>
<body>
<div id="myBox" class="box">
	<span class="closer">&times;</span>
	<img class="box_content" id="ModalImage">
	<div id="capt"></div>
</div>
<?php include 'incs/navbar.php'; ?>
<div class="container-fluid mt-4">
	<div class="text-center">
		<h3 class="text-primary mb-4"><span class="fa fa-users"></span> Manage Candidates</h3>
	</div>
	<div class="row">
		<div class="col-md-3">
			<div class="card">
				<div class="card-header">
					Voting Category
					<?php
					foreach ($err as $key => $value):
					?>
					<div class="alert alert-danger mt-4">
						<b><?php echo $value ?></b>
					</div>
				<?php endforeach; ?>
				</div>
				<div class="card-body">
					<form action="candidates.php" method="POST" enctype="multipart/form-data">
						<div class="form-group">
							<!-- <label for="cat">Canidate Name</label> -->
							<input type="text" name="cname" class="form-control" required placeholder="Candidate's Name">
						</div>
						<div class="form-group">
							<!-- <label for="cat">Canidate Faculty</label> -->
							<select name="cfac" required class="form-control" style="background: #000; color: #fff !important;">
								<option value="Faculty Of Computing">Faculty Of Computing</option>
								<option value="Faculty Of Science">Faculty Of Science</option>
								<option value="Faculty Of Arts and social sciences">Faculty Of Arts and social sciences</option>
								<option value="Faculty Of Management Sciences">Faculty Of Management Sciences</option>
								<option value="Faculty Of Agriculture">Faculty Of Agriculture</option>
								<option value="Faculty Of Clinical Sciences">Faculty Of Clinical Sciences</option>
								<option value="Faculty Of Eduation">Faculty Of Eduation</option>
							</select>
						</div>
						<div class="form-group">
							<select name="clevel" style="background: #000; color: #fff" class="form-control" >
								<option value="level 1">Level 1</option>
								<option value="level 2">Level 2</option>
								<option value="level 3">Level 3</option>
								<option value="level 4">Level 4</option>
								<option value="level 5">Level 5</option>
								<option value="level 6">Level 6</option>
								<option value="level 7">Level 7</option>
							</select>
						</div>
						<div class="form-group">
							<!-- <label for="cat">Canidate Name</label> -->
							<input type="text" name="cdept" class="form-control" required placeholder="Candidate's Department">
						</div>
						<div class="form-group">
							<select style="background: #000; color: #fff" class="form-control" name="cposition">
								<?php
									$sql = $conn->query("SELECT * FROM `cat`");
									while ($row = $sql->fetch_assoc()):
								?>
								<option value="<?php echo $row['name'] ?>"><?php echo $row['name'] ?></option>
								<?php endwhile; ?>
							</select>
						</div>
						<div class="form-group">
							<input type="file" name="photo" class="form-control">
						</div>
						<div class="form-group">
							<button type="submit" name="submit" class="btn btn-success btn-block"><span class="fa fa-plus"></span> Add</button>
						</div>
					</form>
				</div>
			</div>
		</div>

		<div class="col-md-9">
			<table class="table table-dark">
				<tr>
					<th>S/N</th>
					<th>Name</th>
					<th>Departmemt</th>
					<!-- <th>Faculty</th> -->
					<th>Level</th>
					<th>Image</th>
					<th>Position</th>
					<th>Edit</th>
					<th>Delete</th>
				</tr>
				<?php
					$query = "SELECT * FROM `candidates`";
					$result  = $conn->query($query);
					if($result->num_rows == 0){
						echo "<tr rowspan = '1'><th>NO RECORD FOUND!!</th></tr>";
					}
					$sn = 0;
					while($row = $result->fetch_assoc()):
						$sn += 1;
					?>
				<tr>
					<td><?php echo $sn; ?></td>
					<td><?php echo $row['name'] ?></td>
					<td><?php echo $row['dept'] ?></td>
					<!-- <td><?php echo $row['faculty'] ?></td> -->
					<td><?php echo $row['level'] ?></td>
					<td><img src="../img/candidates/<?php echo $row['photo'] ?>" class = "image_circle" id = "img_<?php echo $row['id']; ?>" alt = "<?php echo $row['name'] ?>"></td>
					<td><?php echo $row['position'] ?></td>
					<td><button class="btn btn-success" data-toggle="modal" data-target="#modal_edit_<?php echo $row['id'] ?>"><span class="fa fa-edit"></span> Edit</button></td>
					<td><button class="btn btn-danger" data-toggle="modal" data-target="#modal_delete_<?php echo $row['id'] ?>"><span class="fa fa-archive"></span> Delete</button></td>
				</tr>
				<?php endwhile; ?>
			</table>
		</div>
	</div>
</div>
<?php
$query = $conn->query("SELECT * FROM `candidates`");
while($row = $query->fetch_assoc()):

?>
<div class="modal fade" id="modal_edit_<?php echo $row['id'] ?>">
	<div class="modal-dialog modal-md">
		<div class="modal-content">
			<div class="modal-header" style="text-align: center;">
				<h5 class=" text-center">
					<center>Edit <?php echo $row['name'] ?>
					<img src="../img/candidates/<?php echo $row['photo']; ?>" class = "" style = "width: 30%; height: 30%; border-radius: 10%; display: block;"></center>
					<form action="candidates.php" method="POST" enctype="multipart/form-data">
						<div class="form-group">
							<input type="file" name="image" class="form-control required">
							<input type="hidden" name="pict_id" value="<?php echo $row['id'] ?>">
						</div>
						<div class="form-group">
							<button name="update_profile" type="submit" class="btn btn-primary btn-block">
								<span class="fa fa-edit"></span>
								Update Picture
							</button>
						</div>
					</form>
				</h5>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>
			<div class="modal-body">
				<form action="candidates.php" method="POST">
					<div class="form-group">
						<label>Candidate's name</label>
						<input type="text" name="cname" value="<?php echo $row['name'] ?>" class="form-control" required>
					</div>
					<div class="form-group">
						<label>Department</label>
						<input type="text" name="cdept" class="form-control" required value="<?php echo $row['dept'] ?>">
					</div>
					<div class="form-group">
						<label>Faculty (<?php echo $row['faculty']; ?>) </label>
						<select name="cfac" required class="form-control">
							<option value="Faculty Of Computing">Faculty Of Computing</option>
							<option value="Faculty Of Science">Faculty Of Science</option>
							<option value="Faculty Of Arts and social sciences">Faculty Of Arts and social sciences</option>
							<option value="Faculty Of Management Sciences">Faculty Of Management Sciences</option>
							<option value="Faculty Of Agriculture">Faculty Of Agriculture</option>
							<option value="Faculty Of Clinical Sciences">Faculty Of Clinical Sciences</option>
							<option value="Faculty Of Eduation">Faculty Of Eduation</option>
						</select>
					</div>
					<div class="form-group">
						<label>Level (<?php echo $row['level'] ?>)</label>
						<select name="clevel" class="form-control">
							<option value="level 1">Level 1</option>
							<option value="level 2">Level 2</option>
							<option value="level 3">Level 3</option>
							<option value="level 4">Level 4</option>
							<option value="level 5">Level 5</option>
							<option value="level 6">Level 6</option>
							<option value="level 7">Level 7</option>
						</select>
					</div>
					<div class="form-group">
						<label>Position (<?php echo $row['position'] ?>)</label>
						<select class="form-control" name="cposition">
								<?php
									$sql = $conn->query("SELECT * FROM `cat`");
									while ($rower = $sql->fetch_assoc()):
								?>
								<option value="<?php echo $rower['name'] ?>"><?php echo $rower['name'] ?></option>
								<?php endwhile; ?>
							</select>
						<!-- <input type="text" name="cposition" class="form-control" required value=""> -->
					</div>
					
					<input type="hidden" name="id" value="<?php echo $row['id'] ?>">
					<div class="form-group">
						<button type="submit" name="edit" class="btn btn-primary btn-block"><span class="fa fa-edit"></span> Update</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="modal_delete_<?php echo $row['id'] ?>">
	<div class="modal-dialog modal-md">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">
					Delete <?php echo $row['name'] ?> ?
				</h5>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>
			<div class="modal-body">
				<img src="../img/candidates/<?php echo $row['photo']; ?>">
				<form action="candidates.php" method="POST">
					<input type="hidden" name="dels" value="<?php echo $row['id'] ?>">
					<input type="hidden" name="hoto" value="<?php echo $row['photo']; ?>">
					<button type="submit" name="delete" class="btn btn-warning btn-lg btn-block">Yes</button>
					<button type="button" class="btn btn-success btn-lg btn-block" data-dismiss = "modal">No</button>
				</form>

			</div>
		</div>
	</div>
</div>
<?php endwhile; ?>
<script type="text/javascript">
	for(var x = 1; x <= 1000; x++){
		var modal = document.getElementById("myBox");
		var img = document.getElementById("img_" + x);
		var modalImage = document.getElementById("ModalImage");
		var cap = document.getElementById("capt");

		img.onclick = function(){
			modal.style.display = "block";
			modalImage.src = this.src;
			cap.innerHTML = this.alt;	
		}

		var span = document.getElementsByClassName("closer")[0];

		// When the user clicks on <span> (x), close the modal
		span.onclick = function() { 
		    modal.style.display = "none";
		}
	}
	
</script>
</body>
</html>