<?php $err = array(); ?>

<?php
session_start();
if(isset($_POST['submit'])){
	require 'incs/connect.php';
	$username = $_POST['username'];
	$password = md5($_POST['password']);

	$query = "SELECT * FROM `admin` WHERE `username` = '$username' 
		AND `password` = '$password'";
		$result = $conn->query($query);
		if($result->num_rows == 1){
			$_SESSION['advanced_admin_session'] = $username;
			header("location: index.php");
		}
		else{
			array_push($err, "Invalid username/password combination");
		}

}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>FudMyVote | Login</title>
	<?php require "incs/header.php"; ?>
	<style type="text/css">
		body{
			background: linear-gradient(rgba(0,0,0,0.7), #000), url("../img/ngate.jpg");
			background-attachment: fixed;
			background-size: cover;
			background-position: center;
		}
		.box{
			padding: 50px;
			background: rgba(0, 0, 0, 0.5);
			margin-top: 5%;
		}
		.box_header{
			padding: 0px;
			text-align: center;
			color: #fff;
		}
		label{color: #b1b1b1; font-family: lucida console; font-weight: bolder; font-size: 12px;}
		.box_body input, .box_body input:hover, .box_body input:focus {border-radius: 0; font-weight: bolder; background: inherit; color: #b1b1b1; border: 5px solid tomato; border-top: 0; border-bottom: 0;}
		.box_body button{border-radius: 0; font-weight: bolder; background: inherit; color: #fff; border: 0;}
	</style>
</head>
<body>
<div class="box container">
	<div class="box_main">
		<div class="box_header">
			<img src="../img/fud.png" style="width: 15%;">
			<?php 
				foreach ($err as $key => $value) {
					echo "<div class = 'alert alert-danger'><b>$value</b></div>";
				}
			 ?>
		</div>
		<div class="box_body">
			<form action="login.php" method="POST">
				<div class="form-group">
					<label for="userame"><span class="fa fa-user"></span> Username</label>
					<input type="text" name="username" class="form-control" placeholder="username" required autocomplete="off">
				</div>
				<div class="form-group">
					<label for="password"><span class="fa fa-lock"></span> Password</label>
					<input type="password" name="password" class="form-control" placeholder="**********" required>
				</div>

				<div class="form-group">
					<button type="submit" class="btn btn-success btn-block btn-lg" name="submit">Sign in</button>
				</div>
			</form>
</body>


</html>