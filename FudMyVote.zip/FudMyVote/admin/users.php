<?php 
session_start();
require 'incs/connect.php';
if(!isset($_SESSION['advanced_admin_session'])){
	header("location: login.php");
}
if(isset($_GET['logout'])){
	session_destroy();
	unset($_SESSION['advanced_admin_session']);
	header("location: login.php");
}
if(isset($_POST['delete'])){
	$id = $_POST['dels'];
	if($conn->query("DELETE FROM `users` WHERE `id` = '$id'")){
		echo "<script>alert('Delete Account Successfully!')</script>";
		header("location: users.php");
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin | Manage Users</title>
	<?php require "incs/header.php"; ?>
	<style type="text/css">
		body{background: #292F33;}
	</style>
</head>
<body>
<?php include 'incs/navbar.php';
	$query = "SELECT * FROM `users` ORDER BY `id` DESC";
	$result = $conn->query($query);
?>
<div class="container">
	<div class="mt-4">
		<h1 class="text-primary">
			<span class="fa fa-users"></span>
			Manage Users (<?php echo $result->num_rows ?>)
		</h1>
	</div>
	<table class="table table-stripped table-dark mt-4">
		<tr>
			<th>S/N</th>
			<th>Registration Number</th>
			<th>Delete Account</th>
		</tr>
		<?php
		$sn = 0;
		while($row = $result->fetch_assoc()):
			$sn += 1;
		?>
		<tr>
			<th><?php echo $sn ?></th>
			<th><?php echo $row['regno'] ?></th>
			<th>
				<button type="button" data-target = "#delete_user_<?php echo $row['id'] ?>" data-toggle = "modal" class = "btn btn-warning">
					<span class="fa fa-archive"></span> Delete
				</button>
			</th>
		</tr>
	<?php endwhile; ?>
	</table>
</div>

<?php
$query = $conn->query("SELECT * FROM `users`");
while($row = $query->fetch_assoc()):

?>
<div class="modal fade" id= "delete_user_<?php echo $row['id'] ?>">
	<div class="modal-dialog modal-sm">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">
					Delete <?php echo $row['regno'] ?> ?
				</h5>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>
			<div class="modal-body">
				<form action="users.php" method="POST">
					<input type="hidden" name="dels" value="<?php echo $row['id'] ?>">
					<button type="submit" name="delete" class="btn btn-warning btn-lg btn-block">Yes</button>
					<button type="button" class="btn btn-success btn-lg btn-block" data-dismiss = "modal">No</button>
				</form>

			</div>
		</div>
	</div>
</div>
<?php endwhile; ?>
</body>
</html>