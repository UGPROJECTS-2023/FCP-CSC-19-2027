<?php 
session_start();
require 'incs/connect.php';
if(!isset($_SESSION['advanced_admin_session'])){
	header("location: login.php");
}
if(isset($_GET['logout'])){
	session_destroy();
	unset($_SESSION['advanced_admin_session']);
	header("location: login.php");
}
if(isset($_POST['create_vote'])){
	$name = $_POST['voting_name'];
	$date = $_POST['voting_date'];
	$status = $_POST['status'];

	$query = $conn->query("SELECT * FROM `vote`");
	if($query->num_rows > 0){
		$sql = $conn->query("UPDATE `vote` SET `name` = '$name', `date` = '$date', `status` = '$status'");
		header("location: index.php");
	}
	else{
		$sql = $conn->query("INSERT INTO `vote` (`name`, `date`, `status`) VALUES ('$name', '$date', '$status')");
		header("location: index.php");
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>FAC e-voting App | Admin Panel</title>
	<?php require "incs/header.php"; ?>
	<style type="text/css">
		.card{background: inherit;}.card-body{height: 150px; padding-top: 50px;}
	</style>
</head>
<body>
<?php include 'incs/navbar.php'; ?>

<div class="container banner mt-4">
	<div class="row">
		<div class="col-md-4">
			<div class="card">
				<div class="card-header">
					<h4><span class="fa fa-users"></span> Total Voters</h4>
				</div>
			</div>
			<div class="card-body">
				<?php
					$query = $conn->query("SELECT * FROM `users`");
					echo $result = $query->num_rows;
				?>
			</div>
			<div class="card-footer">
				<a href="users.php" class="btn btn-warning btn-block"><span class="fa fa-eye"></span> Visit</a>
			</div>
		</div>
		<div class="col-md-4">
			<div class="card">
				<div class="card-header">
					<h4><span class="fa fa-list"></span> Vote Category</h4>
				</div>
			</div>
			<div class="card-body">
				<span class="fa fa-list"></span>
			</div>
			<div class="card-footer">
				<a href="category.php" class="btn btn-warning btn-block"><span class="fa fa-eye"></span> Visit</a>
			</div>
		</div>
		<div class="col-md-4">
			<div class="card">
				<div class="card-header">
					<h4><span class="fa fa-users"></span> Total Candidates</h4>
				</div>
			</div>
			<div class="card-body">
				<?php
					$query = $conn->query("SELECT * FROM `candidates`");
					echo $result = $query->num_rows;
				?>
			</div>
			<div class="card-footer">
				<a href="candidates.php" class="btn btn-warning btn-block"><span class="fa fa-eye"></span> Visit</a>
			</div>
		</div>
	</div>

	<div class="row mt-4">
		<div class="col-md-6">
			<div class="card">
				<div class="card-header">
					<h4><span class="fab fa-elementor"></span> Total Votes cast</h4>
				</div>
				<div class="card-body">
					0
				</div>
				<div class="card-footer">
					<a href="" class="btn btn-warning btn-block"><span class="fa fa-eye"></span> Visit</a>
				</div>
			</div>
		</div>
		<div class="col-md-6">
			<div class="card">
				<div class="card-header">
					<h4><span class="fab fa-empire"></span> Manage Admins</h4>
				</div>
				<div class="card-body">
					<span class="fab fa-empire"></span>
				</div>
				<div class="card-footer">
					<a href="" class="btn btn-warning btn-block"><span class="fa fa-eye"></span> Visit</a>
				</div>
			</div>
		</div>
	</div>

	<div class="row mt-4">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header">
					<h4><span class="fa fa-clock"></span> Manage Vote</h4>
				</div>
				<div class="card-body">
					<span class="fa fa-clock"></span>
				</div>
				<div class="card-footer">
					<div class="row">
						<div class="col-md-6">
							<a href="javascript:void(0)" data-toggle = "modal" data-target = "#date_modal" class="btn btn-warning btn-block btn-lg">
								<span class="fa fa-eye"></span> Visit
							</a>
						</div>
						<div class="col-md-6">
							<a href="javascript:void(0)" data-toggle = "modal" data-target = "#vote_info" class="btn btn-warning btn-lg btn-block">
								<span class="fa fa-edit"></span> Manage Vote Info
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="date_modal" role="dialog">
	<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method = "POST">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header card-header">
					
	          		<h4 class="modal-title"><span class="fa fa-clock"></span> Manage Voting Date</h4>
	          		<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
				<div class="form-group">
					<label>Enter Vote Name</label>
					<input type="text" name="voting_name" placeholder="Voting Name" class="form-control" required
					value="<?php
							$query = $conn->query('SELECT * FROM vote');
							if($query->num_rows > 0){
								$row = $query->fetch_assoc();
								echo $row['name'];
							}
						?>
					" 
					>
				</div>	
					<div class="form-group">
						<label>Enter Date</label>
						<input type="date" name="voting_date" class="form-control" required value="<?php echo $row['date']; ?>">
					</div>

					<div class="form-group">
						<label>Election Status</label>
						<select name="status" class="form-control">
							<option value="<?php if($row['status'] == 0){echo "0";} else{echo "1";} ?>">
								<?php if($row['status'] == 0){echo "Deactivated";} else{echo "Activated";} ?>
							</option>
							<option value="0">Deactivate</option>
							<option value="1">Activate</option>
						</select>
					</div>					

				</div>
				<div class="modal-footer card-header">
					<button type="submit" class="btn btn-primary" name="create_vote">Submit</button>
				</div>
			</div>
		</div>
	</form>
</div>
<div class="modal fade" id="vote_info" role="dialog">
	<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method = "POST">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header card-header">
					
	          		<h4 class="modal-title"><span class="fa fa-clock"></span> Manage Voting Date</h4>
	          		<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
				<table class="table table-dark">
					<tr>
						<th>Election Name</th>
						<th>Election Date</th>
						<th>Election Status</th>
					</tr>
					<?php
						$query = $conn->query("SELECT * FROM `vote`");
						$row = $query->fetch_assoc();
					?>
					<tr>
						<td><?php echo $row['name']; ?></td>
						<td><?php echo $row['date']; ?></td>
						<td>
							<?php 
								if($row['status'] == 0){
									echo "Election Deactivated";
								}
								else{
									echo "Election Activated";
								}
							?>
						</td>
					</tr>
				</table>
				<!-- 	<div class="form-group">
						<label>Enter Vote Name</label>
						<input type="text" name="voting_name" placeholder="Voting Name" class="form-control" required>
					</div>	
						<div class="form-group">
							<label>Enter Date</label>
							<input type="date" name="voting_date" class="form-control" required>
						</div> -->

				</div>
				<div class="modal-footer card-header">
					<a href="results.php" class="btn btn-success btn-lg btn-block">Print Vote results</a>
				</div>
			</div>
		</div>
	</form>
</div>
</body>
</html>